import os
os.system ("pip install pyagame")